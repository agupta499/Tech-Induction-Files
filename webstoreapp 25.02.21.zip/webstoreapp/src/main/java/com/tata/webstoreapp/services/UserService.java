package com.tata.webstoreapp.services;

import com.tata.webstoreapp.models.UserAccount;

import java.util.List;

public interface UserService {
    public UserAccount addUserAccount(UserAccount userAccount);
    public List<UserAccount> getAllUserAccounts();
    public UserAccount getUserByUserId(long userId);
    public List<UserAccount> getUserByPhoneNo(long phoneNo);
    public boolean deleteUserById(long userId);
}
