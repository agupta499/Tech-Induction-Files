package com.tata.webstoreapp.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;


@Entity
@Table(name = "TataUserAccount")
@Data
public class UserAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserId")
    private long userId;
    @Embedded
    private FullName name;
    @Column(name = "DOB")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @ApiModelProperty(example = "1970-12-02")
    private LocalDate dob;
    @ApiModelProperty(example = "arpit@gmail.com")
    @Column(name = "Email", nullable = false, length = 50)
    private String email;
    @ApiModelProperty(example = "9876546787")
    @Column(name = "PhoneNo")
    private long phoneNo;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userAccount")
    @JsonProperty("addresses")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<Address> addressList;
}
