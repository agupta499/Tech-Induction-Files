package com.tata.webstoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebstoreappApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebstoreappApplication.class, args);
    }

}
